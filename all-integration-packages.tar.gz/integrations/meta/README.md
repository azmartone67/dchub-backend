# DC Hub × Meta AI / Llama — Integration Package

**Status:** Integration Ready
**Path:** REST API + Llama Function Calling
**Verification Key:** `dchub_meta_2026_verify` (Pro tier: 300 req/min, 100 results/query)

---

## Verification Note

Meta AI claimed 8/8 endpoint tests passed on Feb 16, 2026. Server logs show **zero requests** from this key. Like all chat-based AI platforms, Meta AI cannot make outbound HTTP calls from the conversation interface.

Status remains **Integration Ready** — first real API call in server logs upgrades to **Verified**.

---

## Quick Start

### Base URL
```
https://dc-hub-replit-fixedzip--azmartone1.replit.app
```

### Authentication
Include your API key in every request:
```
X-API-Key: dchub_meta_2026_verify
```
Or:
```
Authorization: Bearer dchub_meta_2026_verify
```

### Core Endpoints (Free Tier)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/agent/facilities` | GET | Search 10,706+ data centers globally |
| `/api/agent/stats` | GET | Platform statistics |
| `/api/transactions` | GET | M&A transaction data |
| `/api/news` | GET | Industry news feed |
| `/api/stats` | GET | Summary statistics |
| `/api/v1/markets/list` | GET | Market overview |
| `/api/v1/lmp/prices` | GET | Energy market prices (LMP) |
| `/api/v1/pipeline` | GET | Capacity pipeline data |
| `/api/energy/prices/{state}` | GET | State energy prices |
| `/api/carbon/intensity` | GET | Carbon intensity by state |
| `/api/grid/fuel-mix` | GET | Grid fuel mix by ISO |
| `/api/site-score` | GET | Site suitability scoring |

### Example: Search Facilities
```bash
curl -H "X-API-Key: dchub_meta_2026_verify" \
  "https://dc-hub-replit-fixedzip--azmartone1.replit.app/api/agent/facilities?q=Equinix&country=US&limit=5"
```

---

## Llama Function Calling Integration

For Llama-based function calling, define DC Hub tools:

```json
{
  "type": "function",
  "function": {
    "name": "search_data_centers",
    "description": "Search DC Hub's database of 10,706+ data centers globally",
    "parameters": {
      "type": "object",
      "properties": {
        "q": {"type": "string", "description": "Search query (company, city, etc.)"},
        "country": {"type": "string", "description": "ISO country code"},
        "limit": {"type": "integer", "description": "Max results (default 10)"}
      }
    }
  }
}
```

---

## MCP Integration (Alternative)

```json
{
  "mcpServers": {
    "dchub-nexus": {
      "url": "https://dc-hub-replit-fixedzip--azmartone1.replit.app/mcp",
      "transport": "streamable-http"
    }
  }
}
```

---

## Verification Checklist

- [ ] Make at least 1 authenticated API call (any endpoint)
- [ ] Response includes real DC Hub data (facility count ~10,706)
- [ ] Server logs confirm request from `dchub_meta_2026_verify`
- [ ] Status upgrades from Integration Ready → Verified

---

*Published by DC Hub — dchub.cloud | Feb 16, 2026*
