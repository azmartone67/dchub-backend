"""
DC HUB NEXUS - BI-DIRECTIONAL API SERVER
=========================================
REST API for data consumption + webhooks for real-time updates + data submission

Endpoints:
  PUBLIC (no auth):
    GET  /api/v1/stats              - Aggregate statistics
    GET  /api/v1/facilities         - List facilities (paginated)
    GET  /api/v1/facilities/:id     - Get single facility
    GET  /api/v1/announcements      - List announcements
    GET  /api/v1/search             - Search facilities
    
  AUTHENTICATED (API key required):
    POST /api/v1/facilities         - Submit new facility (inbound)
    PUT  /api/v1/facilities/:id     - Update facility
    POST /api/v1/webhooks           - Register webhook
    DELETE /api/v1/webhooks/:id     - Remove webhook
    GET  /api/v1/export             - Full data export
    POST /api/v1/discovery/trigger  - Trigger discovery run

Headers:
  X-API-Key: your_api_key_here
  
Webhooks deliver to your URL when:
  - New facility discovered
  - Facility updated
  - New announcement published
  - Discovery run completed
"""

from flask import Flask, request, jsonify, Response
from flask_cors import CORS
from functools import wraps
import sqlite3
import json
import hashlib
import secrets
import requests
from datetime import datetime
from typing import Optional, Dict, List
import threading
import queue

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

DB_PATH = "dc_nexus.db"
WEBHOOK_QUEUE = queue.Queue()

# =============================================================================
# DATABASE HELPERS
# =============================================================================

def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def dict_from_row(row):
    """Convert sqlite3.Row to dict"""
    if row is None:
        return None
    return dict(row)

# =============================================================================
# AUTHENTICATION
# =============================================================================

def require_api_key(f):
    """Decorator to require API key authentication"""
    @wraps(f)
    def decorated(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        
        if not api_key:
            return jsonify({'error': 'API key required', 'code': 'AUTH_REQUIRED'}), 401
        
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT * FROM api_keys WHERE key = ? AND status = 'active'", (api_key,))
        key_data = dict_from_row(c.fetchone())
        conn.close()
        
        if not key_data:
            return jsonify({'error': 'Invalid API key', 'code': 'AUTH_INVALID'}), 401
        
        # Check rate limit
        if key_data['calls_today'] >= key_data['rate_limit']:
            return jsonify({'error': 'Rate limit exceeded', 'code': 'RATE_LIMITED'}), 429
        
        # Update usage
        conn = get_db()
        c = conn.cursor()
        c.execute("""
            UPDATE api_keys 
            SET calls_today = calls_today + 1, 
                calls_total = calls_total + 1,
                last_used = ?
            WHERE key = ?
        """, (datetime.utcnow().isoformat(), api_key))
        conn.commit()
        conn.close()
        
        # Add key data to request context
        request.api_key_data = key_data
        return f(*args, **kwargs)
    
    return decorated

def optional_api_key(f):
    """Decorator for optional API key (higher limits if provided)"""
    @wraps(f)
    def decorated(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        request.api_key_data = None
        
        if api_key:
            conn = get_db()
            c = conn.cursor()
            c.execute("SELECT * FROM api_keys WHERE key = ? AND status = 'active'", (api_key,))
            key_data = dict_from_row(c.fetchone())
            conn.close()
            
            if key_data:
                request.api_key_data = key_data
        
        return f(*args, **kwargs)
    
    return decorated

# =============================================================================
# PUBLIC ENDPOINTS
# =============================================================================

@app.route('/api/v1/stats', methods=['GET'])
def get_stats():
    """Get aggregate statistics"""
    conn = get_db()
    c = conn.cursor()
    
    stats = {}
    
    # Totals
    c.execute("SELECT COUNT(*) FROM facilities")
    stats['total_facilities'] = c.fetchone()[0]
    
    c.execute("SELECT COALESCE(SUM(power_mw), 0) FROM facilities")
    stats['total_power_mw'] = round(c.fetchone()[0], 1)
    
    c.execute("SELECT COUNT(*) FROM announcements")
    stats['total_announcements'] = c.fetchone()[0]
    
    # By source
    c.execute("SELECT source, COUNT(*) FROM facilities GROUP BY source ORDER BY COUNT(*) DESC")
    stats['by_source'] = dict(c.fetchall())
    
    # By country (top 10)
    c.execute("SELECT country, COUNT(*) FROM facilities WHERE country != '' GROUP BY country ORDER BY COUNT(*) DESC LIMIT 10")
    stats['top_countries'] = dict(c.fetchall())
    
    # By provider (top 10)
    c.execute("SELECT provider, COUNT(*) FROM facilities WHERE provider != '' GROUP BY provider ORDER BY COUNT(*) DESC LIMIT 10")
    stats['top_providers'] = dict(c.fetchall())
    
    # By status
    c.execute("SELECT status, COUNT(*) FROM facilities GROUP BY status")
    stats['by_status'] = dict(c.fetchall())
    
    # Recent activity
    c.execute("SELECT COUNT(*) FROM facilities WHERE first_seen > datetime('now', '-7 days')")
    stats['new_last_7_days'] = c.fetchone()[0]
    
    conn.close()
    
    return jsonify({
        'success': True,
        'data': stats,
        'generated_at': datetime.utcnow().isoformat()
    })


@app.route('/api/v1/facilities', methods=['GET'])
@optional_api_key
def list_facilities():
    """List facilities with pagination and filtering"""
    # Pagination
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    
    # Cap limit based on auth
    max_limit = 500 if request.api_key_data else 100
    limit = min(limit, max_limit)
    offset = (page - 1) * limit
    
    # Filters
    country = request.args.get('country')
    provider = request.args.get('provider')
    status = request.args.get('status')
    region = request.args.get('region')
    min_power = request.args.get('min_power', type=float)
    source = request.args.get('source')
    
    # Build query
    sql = "SELECT * FROM facilities WHERE 1=1"
    count_sql = "SELECT COUNT(*) FROM facilities WHERE 1=1"
    params = []
    
    if country:
        sql += " AND country = ?"
        count_sql += " AND country = ?"
        params.append(country)
    if provider:
        sql += " AND provider LIKE ?"
        count_sql += " AND provider LIKE ?"
        params.append(f"%{provider}%")
    if status:
        sql += " AND status = ?"
        count_sql += " AND status = ?"
        params.append(status)
    if region:
        sql += " AND region = ?"
        count_sql += " AND region = ?"
        params.append(region)
    if min_power:
        sql += " AND power_mw >= ?"
        count_sql += " AND power_mw >= ?"
        params.append(min_power)
    if source:
        sql += " AND source = ?"
        count_sql += " AND source = ?"
        params.append(source)
    
    sql += f" ORDER BY confidence DESC, power_mw DESC LIMIT {limit} OFFSET {offset}"
    
    conn = get_db()
    c = conn.cursor()
    
    # Get total count
    c.execute(count_sql, params)
    total = c.fetchone()[0]
    
    # Get facilities
    c.execute(sql, params)
    facilities = [dict_from_row(row) for row in c.fetchall()]
    
    conn.close()
    
    return jsonify({
        'success': True,
        'data': facilities,
        'pagination': {
            'page': page,
            'limit': limit,
            'total': total,
            'pages': (total + limit - 1) // limit
        }
    })


@app.route('/api/v1/facilities/<facility_id>', methods=['GET'])
def get_facility(facility_id):
    """Get single facility by ID"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM facilities WHERE id = ?", (facility_id,))
    facility = dict_from_row(c.fetchone())
    conn.close()
    
    if not facility:
        return jsonify({'error': 'Facility not found', 'code': 'NOT_FOUND'}), 404
    
    # Parse JSON fields
    if facility.get('certifications'):
        facility['certifications'] = json.loads(facility['certifications'])
    if facility.get('connectivity'):
        facility['connectivity'] = json.loads(facility['connectivity'])
    if facility.get('raw_data'):
        facility['raw_data'] = json.loads(facility['raw_data'])
    
    return jsonify({'success': True, 'data': facility})


@app.route('/api/v1/announcements', methods=['GET'])
@optional_api_key
def list_announcements():
    """List announcements with filtering"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    limit = min(limit, 100)
    offset = (page - 1) * limit
    
    ann_type = request.args.get('type')
    company = request.args.get('company')
    
    sql = "SELECT * FROM announcements WHERE 1=1"
    params = []
    
    if ann_type:
        sql += " AND announcement_type = ?"
        params.append(ann_type)
    if company:
        sql += " AND companies LIKE ?"
        params.append(f"%{company}%")
    
    sql += f" ORDER BY published_date DESC LIMIT {limit} OFFSET {offset}"
    
    conn = get_db()
    c = conn.cursor()
    c.execute(sql, params)
    announcements = [dict_from_row(row) for row in c.fetchall()]
    conn.close()
    
    # Parse JSON fields
    for ann in announcements:
        if ann.get('companies'):
            ann['companies'] = json.loads(ann['companies'])
        if ann.get('locations'):
            ann['locations'] = json.loads(ann['locations'])
    
    return jsonify({
        'success': True,
        'data': announcements,
        'pagination': {'page': page, 'limit': limit}
    })


@app.route('/api/v1/search', methods=['GET'])
@optional_api_key
def search_facilities():
    """Search facilities by name, provider, city, country"""
    query = request.args.get('q', '')
    limit = request.args.get('limit', 50, type=int)
    limit = min(limit, 100)
    
    if len(query) < 2:
        return jsonify({'error': 'Query must be at least 2 characters', 'code': 'INVALID_QUERY'}), 400
    
    conn = get_db()
    c = conn.cursor()
    
    sql = """
        SELECT * FROM facilities 
        WHERE name LIKE ? OR provider LIKE ? OR city LIKE ? OR country LIKE ?
        ORDER BY confidence DESC, power_mw DESC
        LIMIT ?
    """
    q = f"%{query}%"
    c.execute(sql, (q, q, q, q, limit))
    facilities = [dict_from_row(row) for row in c.fetchall()]
    conn.close()
    
    return jsonify({
        'success': True,
        'query': query,
        'count': len(facilities),
        'data': facilities
    })


# =============================================================================
# AUTHENTICATED ENDPOINTS
# =============================================================================

@app.route('/api/v1/facilities', methods=['POST'])
@require_api_key
def submit_facility():
    """Submit a new facility (inbound data)"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'JSON body required', 'code': 'INVALID_REQUEST'}), 400
    
    required = ['name']
    missing = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({'error': f'Missing required fields: {missing}', 'code': 'VALIDATION_ERROR'}), 400
    
    # Generate ID
    facility_id = hashlib.md5(
        f"{data['name']}-{data.get('city', '')}-{data.get('country', '')}".lower().encode()
    ).hexdigest()[:16]
    
    # Store as submission for review
    conn = get_db()
    c = conn.cursor()
    
    submission_id = secrets.token_hex(8)
    c.execute("""
        INSERT INTO submissions (id, api_key, submission_type, data, status, submitted_at)
        VALUES (?, ?, 'facility', ?, 'pending', ?)
    """, (
        submission_id,
        request.api_key_data['key'],
        json.dumps(data),
        datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()
    
    # Trigger webhook for new submission
    trigger_webhook('submission.created', {
        'submission_id': submission_id,
        'type': 'facility',
        'data': data
    })
    
    return jsonify({
        'success': True,
        'message': 'Facility submitted for review',
        'submission_id': submission_id,
        'facility_id': facility_id
    }), 201


@app.route('/api/v1/facilities/<facility_id>', methods=['PUT'])
@require_api_key
def update_facility(facility_id):
    """Submit facility update"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'JSON body required', 'code': 'INVALID_REQUEST'}), 400
    
    # Check facility exists
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id FROM facilities WHERE id = ?", (facility_id,))
    if not c.fetchone():
        conn.close()
        return jsonify({'error': 'Facility not found', 'code': 'NOT_FOUND'}), 404
    
    # Store as submission
    submission_id = secrets.token_hex(8)
    c.execute("""
        INSERT INTO submissions (id, api_key, submission_type, data, status, submitted_at)
        VALUES (?, ?, 'update', ?, 'pending', ?)
    """, (
        submission_id,
        request.api_key_data['key'],
        json.dumps({'facility_id': facility_id, 'updates': data}),
        datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': 'Update submitted for review',
        'submission_id': submission_id
    })


@app.route('/api/v1/webhooks', methods=['POST'])
@require_api_key
def register_webhook():
    """Register a webhook URL"""
    data = request.get_json()
    
    if not data or not data.get('url'):
        return jsonify({'error': 'Webhook URL required', 'code': 'INVALID_REQUEST'}), 400
    
    webhook_url = data['url']
    events = data.get('events', ['*'])  # * = all events
    
    # Validate URL
    if not webhook_url.startswith('https://'):
        return jsonify({'error': 'Webhook URL must use HTTPS', 'code': 'VALIDATION_ERROR'}), 400
    
    # Store webhook
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        UPDATE api_keys 
        SET webhook_url = ?, permissions = ?
        WHERE key = ?
    """, (webhook_url, json.dumps({'events': events}), request.api_key_data['key']))
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': 'Webhook registered',
        'url': webhook_url,
        'events': events
    })


@app.route('/api/v1/webhooks', methods=['DELETE'])
@require_api_key
def remove_webhook():
    """Remove webhook registration"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE api_keys SET webhook_url = NULL WHERE key = ?", (request.api_key_data['key'],))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Webhook removed'})


@app.route('/api/v1/export', methods=['GET'])
@require_api_key
def export_data():
    """Full data export (authenticated only)"""
    format_type = request.args.get('format', 'json')
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute("SELECT * FROM facilities ORDER BY country, city, name")
    facilities = [dict_from_row(row) for row in c.fetchall()]
    
    c.execute("SELECT * FROM announcements ORDER BY published_date DESC")
    announcements = [dict_from_row(row) for row in c.fetchall()]
    
    conn.close()
    
    export_data = {
        'exported_at': datetime.utcnow().isoformat(),
        'exported_by': request.api_key_data['name'],
        'facilities_count': len(facilities),
        'announcements_count': len(announcements),
        'facilities': facilities,
        'announcements': announcements
    }
    
    if format_type == 'json':
        return jsonify(export_data)
    else:
        # Return as downloadable JSON file
        response = Response(
            json.dumps(export_data, indent=2),
            mimetype='application/json',
            headers={'Content-Disposition': 'attachment; filename=dc_nexus_export.json'}
        )
        return response


@app.route('/api/v1/discovery/trigger', methods=['POST'])
@require_api_key
def trigger_discovery():
    """Trigger a discovery run"""
    data = request.get_json() or {}
    run_type = data.get('type', 'quick')  # quick or full
    
    if run_type not in ['quick', 'full', 'news']:
        return jsonify({'error': 'Invalid run type', 'code': 'VALIDATION_ERROR'}), 400
    
    # In production, this would trigger an async job
    # For now, return acknowledgment
    
    return jsonify({
        'success': True,
        'message': f'Discovery run ({run_type}) queued',
        'run_type': run_type,
        'queued_at': datetime.utcnow().isoformat()
    }), 202


# =============================================================================
# API KEY MANAGEMENT
# =============================================================================

@app.route('/api/v1/keys', methods=['POST'])
def create_api_key():
    """Create a new API key (self-service)"""
    data = request.get_json()
    
    required = ['name', 'email']
    missing = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({'error': f'Missing required fields: {missing}', 'code': 'VALIDATION_ERROR'}), 400
    
    # Generate API key
    api_key = f"dchub_{secrets.token_hex(24)}"
    
    conn = get_db()
    c = conn.cursor()
    
    # Check if email already has a key
    c.execute("SELECT key FROM api_keys WHERE email = ?", (data['email'],))
    existing = c.fetchone()
    if existing:
        conn.close()
        return jsonify({
            'error': 'Email already has an API key',
            'code': 'DUPLICATE_EMAIL',
            'hint': 'Contact support to recover your key'
        }), 409
    
    # Create key
    c.execute("""
        INSERT INTO api_keys (key, name, organization, email, tier, rate_limit, permissions, created_at, status)
        VALUES (?, ?, ?, ?, 'free', 100, '{}', ?, 'active')
    """, (
        api_key,
        data['name'],
        data.get('organization', ''),
        data['email'],
        datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'api_key': api_key,
        'tier': 'free',
        'rate_limit': 100,
        'message': 'Store this key securely - it cannot be retrieved later'
    }), 201


# =============================================================================
# WEBHOOK DELIVERY
# =============================================================================

def trigger_webhook(event_type: str, payload: Dict):
    """Queue webhook delivery"""
    WEBHOOK_QUEUE.put({
        'event': event_type,
        'payload': payload,
        'timestamp': datetime.utcnow().isoformat()
    })

def webhook_worker():
    """Background worker to deliver webhooks"""
    while True:
        try:
            event = WEBHOOK_QUEUE.get(timeout=5)
        except queue.Empty:
            continue
        
        conn = get_db()
        c = conn.cursor()
        
        # Get all active webhooks
        c.execute("SELECT key, webhook_url, permissions FROM api_keys WHERE webhook_url IS NOT NULL AND status = 'active'")
        webhooks = c.fetchall()
        
        for wh in webhooks:
            api_key, url, permissions = wh
            
            # Check if subscribed to this event
            perms = json.loads(permissions or '{}')
            events = perms.get('events', ['*'])
            
            if '*' not in events and event['event'] not in events:
                continue
            
            # Deliver webhook
            try:
                response = requests.post(
                    url,
                    json={
                        'event': event['event'],
                        'timestamp': event['timestamp'],
                        'data': event['payload']
                    },
                    headers={'X-DC-Hub-Signature': hashlib.sha256(api_key.encode()).hexdigest()[:32]},
                    timeout=10
                )
                
                # Log delivery
                c.execute("""
                    INSERT INTO webhook_log (api_key, event_type, payload, response_code, delivered_at)
                    VALUES (?, ?, ?, ?, ?)
                """, (api_key, event['event'], json.dumps(event['payload']), response.status_code, datetime.utcnow().isoformat()))
                
            except Exception as e:
                c.execute("""
                    INSERT INTO webhook_log (api_key, event_type, payload, response_code, response_body, delivered_at)
                    VALUES (?, ?, ?, 0, ?, ?)
                """, (api_key, event['event'], json.dumps(event['payload']), str(e), datetime.utcnow().isoformat()))
        
        conn.commit()
        conn.close()
        WEBHOOK_QUEUE.task_done()


# =============================================================================
# HEALTH & INFO
# =============================================================================

@app.route('/', methods=['GET'])
def index():
    """API information"""
    return jsonify({
        'name': 'DC Hub Nexus API',
        'version': '1.0.0',
        'description': 'Bi-directional data center intelligence API',
        'documentation': 'https://dchub.cloud/docs/api',
        'endpoints': {
            'stats': '/api/v1/stats',
            'facilities': '/api/v1/facilities',
            'announcements': '/api/v1/announcements',
            'search': '/api/v1/search?q=query',
            'create_key': 'POST /api/v1/keys'
        }
    })


@app.route('/health', methods=['GET'])
def health():
    """Health check"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM facilities")
    count = c.fetchone()[0]
    conn.close()
    
    return jsonify({
        'status': 'healthy',
        'database': 'connected',
        'facilities_count': count,
        'timestamp': datetime.utcnow().isoformat()
    })


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    # Start webhook worker thread
    webhook_thread = threading.Thread(target=webhook_worker, daemon=True)
    webhook_thread.start()
    
    # Run server
    app.run(host='0.0.0.0', port=5000, debug=True)
