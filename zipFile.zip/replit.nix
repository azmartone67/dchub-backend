{ pkgs }: {
  deps = [
    pkgs.python311
    pkgs.python311Packages.pip
    pkgs.python311Packages.virtualenv
    pkgs.libxml2
    pkgs.libxslt
    pkgs.openssl
    pkgs.cacert
  ];
}
