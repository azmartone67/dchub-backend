#!/usr/bin/env python3
"""
DC HUB NEXUS - UNIFIED DEPLOYMENT FOR REPLIT
=============================================
Combines discovery engine + API server in one process.
Auto-runs initial discovery on startup.

Environment Variables:
  DCHUB_RUN_DISCOVERY - Set to '1' to run discovery on startup
  DCHUB_DISCOVERY_MODE - 'quick', 'full', or 'none' (default: quick)
  PORT - Server port (default: 5000)
"""

import os
import threading
import time
import logging
from datetime import datetime

# Configure logging first
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('DC-Hub')

# Import components (they're in the same directory)
from discovery_nexus import NexusEngine, NexusDatabase
from api_server import app, DB_PATH

# Global discovery engine instance
engine = None
discovery_lock = threading.Lock()
last_discovery_run = None

def init_discovery_engine():
    """Initialize the discovery engine"""
    global engine
    engine = NexusEngine(DB_PATH)
    logger.info("✅ Discovery engine initialized")
    return engine

def run_discovery_async(mode='quick'):
    """Run discovery in background thread"""
    global last_discovery_run
    
    def _run():
        global last_discovery_run
        with discovery_lock:
            try:
                if mode == 'quick':
                    result = engine.run_quick()
                elif mode == 'full':
                    result = engine.run_full()
                elif mode == 'news':
                    result = engine.run_news_only()
                else:
                    return
                
                last_discovery_run = {
                    'completed_at': datetime.utcnow().isoformat(),
                    'mode': mode,
                    'result': result
                }
                logger.info(f"✅ Discovery run ({mode}) completed")
            except Exception as e:
                logger.error(f"❌ Discovery error: {e}")
    
    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    return thread

# =============================================================================
# ADDITIONAL API ENDPOINTS FOR DISCOVERY CONTROL
# =============================================================================

from flask import jsonify, request

@app.route('/api/v1/discovery/status', methods=['GET'])
def discovery_status():
    """Get discovery engine status"""
    return jsonify({
        'success': True,
        'engine_initialized': engine is not None,
        'last_run': last_discovery_run,
        'discovery_running': discovery_lock.locked()
    })

@app.route('/api/v1/discovery/run', methods=['POST'])
def run_discovery():
    """Trigger a discovery run"""
    data = request.get_json() or {}
    mode = data.get('mode', 'quick')
    
    if mode not in ['quick', 'full', 'news']:
        return jsonify({'error': 'Invalid mode. Use: quick, full, or news'}), 400
    
    if discovery_lock.locked():
        return jsonify({
            'success': False,
            'message': 'Discovery already running',
            'last_run': last_discovery_run
        }), 409
    
    run_discovery_async(mode)
    
    return jsonify({
        'success': True,
        'message': f'Discovery run ({mode}) started',
        'started_at': datetime.utcnow().isoformat()
    }), 202

# =============================================================================
# SCHEDULED DISCOVERY (BACKGROUND)
# =============================================================================

def discovery_scheduler():
    """Background scheduler for periodic discovery"""
    while True:
        try:
            # Run quick discovery every 6 hours
            time.sleep(6 * 3600)
            if not discovery_lock.locked():
                logger.info("🔄 Running scheduled discovery...")
                run_discovery_async('quick')
        except Exception as e:
            logger.error(f"Scheduler error: {e}")

# =============================================================================
# STARTUP
# =============================================================================

def startup():
    """Startup routine"""
    logger.info("=" * 60)
    logger.info("🚀 DC HUB NEXUS - STARTING UP")
    logger.info("=" * 60)
    
    # Initialize engine
    init_discovery_engine()
    
    # Check if we should run initial discovery
    run_on_start = os.environ.get('DCHUB_RUN_DISCOVERY', '1') == '1'
    discovery_mode = os.environ.get('DCHUB_DISCOVERY_MODE', 'quick')
    
    if run_on_start and discovery_mode != 'none':
        logger.info(f"🔍 Running initial discovery ({discovery_mode})...")
        run_discovery_async(discovery_mode)
    
    # Start scheduler thread
    scheduler_thread = threading.Thread(target=discovery_scheduler, daemon=True)
    scheduler_thread.start()
    logger.info("📅 Discovery scheduler started")

if __name__ == '__main__':
    # Run startup
    startup()
    
    # Get port from environment (Replit sets this)
    port = int(os.environ.get('PORT', 5000))
    
    logger.info(f"🌐 Starting API server on port {port}")
    logger.info("=" * 60)
    
    # Run Flask app
    # Use threaded=True for better concurrency
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
