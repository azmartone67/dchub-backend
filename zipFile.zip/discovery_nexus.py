#!/usr/bin/env python3
"""
DC HUB DATA NEXUS - ULTIMATE DISCOVERY ENGINE v3.0
===================================================
Target: 50,000+ facilities from 15+ sources
Bi-directional API ecosystem with webhooks

Sources:
  FREE APIs (Tier 1 - Run Daily):
    1. PeeringDB - 5,000+ facilities with IX/network data
    2. OpenStreetMap/Overpass - 10,000+ tagged data centers globally
    3. Wikidata - Structured data center entities
    4. SEC EDGAR - REIT filings (DLR, EQIX, AMT, CCI, SBAC)
    5. GitHub Awesome Lists - Community-curated DC lists
    
  Web Scraping (Tier 2 - Run Weekly):
    6. Cloudscene - 6,100+ data centers
    7. DatacenterHawk - 35+ US markets
    8. Data Center Map - 5,000+ global
    9. Colocation America - Provider directory
    10. Provider Websites - Equinix, DLR, CyrusOne, QTS, CoreSite, Vantage, etc.
    
  News & Announcements (Tier 3 - Run Hourly):
    11. RSS Feeds - DCD, DCK, DCF, Bisnow
    12. Google News API - "data center" announcements
    13. PR Newswire/Business Wire - Press releases
    14. SEC 8-K Filings - Material events
    15. LinkedIn Company Updates - Provider pages
    
  Premium/Partnership (Tier 4 - Future):
    16. CBRE Data Center Solutions API
    17. JLL Data Center Practice
    18. Cushman & Wakefield
    19. Commercial real estate MLSs
"""

import os
import json
import hashlib
import sqlite3
import requests
import logging
import time
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict, field
from concurrent.futures import ThreadPoolExecutor, as_completed
from abc import ABC, abstractmethod
import xml.etree.ElementTree as ET

# Optional imports with fallbacks
try:
    from bs4 import BeautifulSoup
    HAS_BS4 = True
except ImportError:
    HAS_BS4 = False
    
try:
    import feedparser
    HAS_FEEDPARSER = True
except ImportError:
    HAS_FEEDPARSER = False

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('DCNexus')

# =============================================================================
# DATA MODELS
# =============================================================================

@dataclass
class Facility:
    """Standardized facility record"""
    id: str
    name: str
    provider: str = ""
    address: str = ""
    city: str = ""
    state: str = ""
    country: str = ""
    region: str = ""  # NA, EMEA, APAC, LATAM
    latitude: float = 0.0
    longitude: float = 0.0
    power_mw: float = 0.0
    sqft: int = 0
    status: str = "active"  # active, construction, planned, closed
    tier: int = 0  # 1-4
    certifications: List[str] = field(default_factory=list)
    connectivity: Dict[str, Any] = field(default_factory=dict)  # carriers, IXPs, etc
    source: str = ""
    source_url: str = ""
    source_id: str = ""  # Original ID from source
    confidence: float = 0.0
    first_seen: str = ""
    last_updated: str = ""
    raw_data: Dict = field(default_factory=dict)

@dataclass
class Announcement:
    """Market announcement/news item"""
    id: str
    title: str
    summary: str = ""
    content: str = ""
    source: str = ""
    source_url: str = ""
    published_date: str = ""
    announcement_type: str = ""  # new_build, expansion, acquisition, funding, partnership
    companies: List[str] = field(default_factory=list)
    locations: List[str] = field(default_factory=list)
    power_mw: float = 0.0
    investment_usd: float = 0.0
    sqft: int = 0
    expected_completion: str = ""
    confidence: float = 0.0
    processed_at: str = ""

@dataclass  
class DataSource:
    """Metadata about a data source"""
    name: str
    source_type: str  # api, scrape, rss, manual
    url: str
    reliability: float  # 0-1
    update_frequency: str  # hourly, daily, weekly
    requires_auth: bool = False
    rate_limit_seconds: float = 1.0
    last_run: str = ""
    facilities_count: int = 0
    announcements_count: int = 0
    status: str = "active"

# =============================================================================
# DATABASE MANAGER
# =============================================================================

class NexusDatabase:
    """SQLite database with full-text search and analytics"""
    
    def __init__(self, db_path: str = "dc_nexus.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        # Main facilities table
        c.execute('''
            CREATE TABLE IF NOT EXISTS facilities (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                provider TEXT,
                address TEXT,
                city TEXT,
                state TEXT,
                country TEXT,
                region TEXT,
                latitude REAL,
                longitude REAL,
                power_mw REAL DEFAULT 0,
                sqft INTEGER DEFAULT 0,
                status TEXT DEFAULT 'active',
                tier INTEGER DEFAULT 0,
                certifications TEXT,
                connectivity TEXT,
                source TEXT,
                source_url TEXT,
                source_id TEXT,
                confidence REAL DEFAULT 0,
                first_seen TEXT,
                last_updated TEXT,
                raw_data TEXT,
                UNIQUE(name, city, country)
            )
        ''')
        
        # Announcements table
        c.execute('''
            CREATE TABLE IF NOT EXISTS announcements (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                summary TEXT,
                content TEXT,
                source TEXT,
                source_url TEXT,
                published_date TEXT,
                announcement_type TEXT,
                companies TEXT,
                locations TEXT,
                power_mw REAL DEFAULT 0,
                investment_usd REAL DEFAULT 0,
                sqft INTEGER DEFAULT 0,
                expected_completion TEXT,
                confidence REAL DEFAULT 0,
                processed_at TEXT
            )
        ''')
        
        # Data sources tracking
        c.execute('''
            CREATE TABLE IF NOT EXISTS data_sources (
                name TEXT PRIMARY KEY,
                source_type TEXT,
                url TEXT,
                reliability REAL,
                update_frequency TEXT,
                requires_auth INTEGER DEFAULT 0,
                rate_limit_seconds REAL DEFAULT 1.0,
                last_run TEXT,
                facilities_count INTEGER DEFAULT 0,
                announcements_count INTEGER DEFAULT 0,
                status TEXT DEFAULT 'active'
            )
        ''')
        
        # API keys and webhooks for bi-directional integration
        c.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                key TEXT PRIMARY KEY,
                name TEXT,
                organization TEXT,
                email TEXT,
                tier TEXT DEFAULT 'free',
                calls_today INTEGER DEFAULT 0,
                calls_total INTEGER DEFAULT 0,
                rate_limit INTEGER DEFAULT 100,
                permissions TEXT,
                webhook_url TEXT,
                created_at TEXT,
                last_used TEXT,
                status TEXT DEFAULT 'active'
            )
        ''')
        
        # Inbound data submissions
        c.execute('''
            CREATE TABLE IF NOT EXISTS submissions (
                id TEXT PRIMARY KEY,
                api_key TEXT,
                submission_type TEXT,
                data TEXT,
                status TEXT DEFAULT 'pending',
                reviewed_by TEXT,
                reviewed_at TEXT,
                submitted_at TEXT,
                FOREIGN KEY (api_key) REFERENCES api_keys(key)
            )
        ''')
        
        # Webhook delivery log
        c.execute('''
            CREATE TABLE IF NOT EXISTS webhook_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_key TEXT,
                event_type TEXT,
                payload TEXT,
                response_code INTEGER,
                response_body TEXT,
                delivered_at TEXT,
                FOREIGN KEY (api_key) REFERENCES api_keys(key)
            )
        ''')
        
        # Discovery run history
        c.execute('''
            CREATE TABLE IF NOT EXISTS discovery_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_type TEXT,
                sources_checked INTEGER,
                facilities_new INTEGER,
                facilities_updated INTEGER,
                announcements_new INTEGER,
                duration_seconds REAL,
                started_at TEXT,
                completed_at TEXT,
                status TEXT,
                log TEXT
            )
        ''')
        
        # Create indexes for fast queries
        c.execute('CREATE INDEX IF NOT EXISTS idx_facilities_city ON facilities(city)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_facilities_country ON facilities(country)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_facilities_provider ON facilities(provider)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_facilities_status ON facilities(status)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_facilities_source ON facilities(source)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_announcements_type ON announcements(announcement_type)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_announcements_date ON announcements(published_date)')
        
        conn.commit()
        conn.close()
        logger.info(f"Database initialized: {self.db_path}")
    
    def upsert_facility(self, facility: Facility) -> Tuple[str, bool]:
        """Insert or update facility. Returns (id, is_new)"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        # Check if exists
        c.execute("SELECT id, confidence FROM facilities WHERE id = ?", (facility.id,))
        existing = c.fetchone()
        
        now = datetime.utcnow().isoformat()
        
        if existing:
            # Update if new data has higher confidence
            if facility.confidence >= existing[1]:
                c.execute('''
                    UPDATE facilities SET
                        name=?, provider=?, address=?, city=?, state=?, country=?, region=?,
                        latitude=?, longitude=?, power_mw=?, sqft=?, status=?, tier=?,
                        certifications=?, connectivity=?, source=?, source_url=?, source_id=?,
                        confidence=?, last_updated=?, raw_data=?
                    WHERE id=?
                ''', (
                    facility.name, facility.provider, facility.address, facility.city,
                    facility.state, facility.country, facility.region, facility.latitude,
                    facility.longitude, facility.power_mw, facility.sqft, facility.status,
                    facility.tier, json.dumps(facility.certifications), 
                    json.dumps(facility.connectivity), facility.source, facility.source_url,
                    facility.source_id, facility.confidence, now, json.dumps(facility.raw_data),
                    facility.id
                ))
            conn.commit()
            conn.close()
            return (facility.id, False)
        else:
            # Insert new
            c.execute('''
                INSERT INTO facilities (
                    id, name, provider, address, city, state, country, region,
                    latitude, longitude, power_mw, sqft, status, tier,
                    certifications, connectivity, source, source_url, source_id,
                    confidence, first_seen, last_updated, raw_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                facility.id, facility.name, facility.provider, facility.address,
                facility.city, facility.state, facility.country, facility.region,
                facility.latitude, facility.longitude, facility.power_mw, facility.sqft,
                facility.status, facility.tier, json.dumps(facility.certifications),
                json.dumps(facility.connectivity), facility.source, facility.source_url,
                facility.source_id, facility.confidence, now, now, json.dumps(facility.raw_data)
            ))
            conn.commit()
            conn.close()
            return (facility.id, True)
    
    def upsert_announcement(self, announcement: Announcement) -> Tuple[str, bool]:
        """Insert announcement if not exists"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        c.execute("SELECT id FROM announcements WHERE id = ?", (announcement.id,))
        if c.fetchone():
            conn.close()
            return (announcement.id, False)
        
        c.execute('''
            INSERT INTO announcements (
                id, title, summary, content, source, source_url, published_date,
                announcement_type, companies, locations, power_mw, investment_usd,
                sqft, expected_completion, confidence, processed_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            announcement.id, announcement.title, announcement.summary, announcement.content,
            announcement.source, announcement.source_url, announcement.published_date,
            announcement.announcement_type, json.dumps(announcement.companies),
            json.dumps(announcement.locations), announcement.power_mw, announcement.investment_usd,
            announcement.sqft, announcement.expected_completion, announcement.confidence,
            datetime.utcnow().isoformat()
        ))
        conn.commit()
        conn.close()
        return (announcement.id, True)
    
    def get_stats(self) -> Dict:
        """Get comprehensive statistics"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        stats = {}
        
        # Totals
        c.execute("SELECT COUNT(*) FROM facilities")
        stats['total_facilities'] = c.fetchone()[0]
        
        c.execute("SELECT COALESCE(SUM(power_mw), 0) FROM facilities")
        stats['total_power_mw'] = round(c.fetchone()[0], 1)
        
        c.execute("SELECT COALESCE(SUM(sqft), 0) FROM facilities")
        stats['total_sqft'] = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM announcements")
        stats['total_announcements'] = c.fetchone()[0]
        
        # By source
        c.execute("SELECT source, COUNT(*) FROM facilities GROUP BY source ORDER BY COUNT(*) DESC")
        stats['by_source'] = dict(c.fetchall())
        
        # By country (top 20)
        c.execute("SELECT country, COUNT(*) FROM facilities WHERE country != '' GROUP BY country ORDER BY COUNT(*) DESC LIMIT 20")
        stats['by_country'] = dict(c.fetchall())
        
        # By provider (top 20)
        c.execute("SELECT provider, COUNT(*) FROM facilities WHERE provider != '' GROUP BY provider ORDER BY COUNT(*) DESC LIMIT 20")
        stats['by_provider'] = dict(c.fetchall())
        
        # By status
        c.execute("SELECT status, COUNT(*) FROM facilities GROUP BY status")
        stats['by_status'] = dict(c.fetchall())
        
        # By region
        c.execute("SELECT region, COUNT(*) FROM facilities WHERE region != '' GROUP BY region")
        stats['by_region'] = dict(c.fetchall())
        
        # Recent activity
        c.execute("SELECT COUNT(*) FROM facilities WHERE first_seen > datetime('now', '-7 days')")
        stats['new_last_7_days'] = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM announcements WHERE published_date > datetime('now', '-7 days')")
        stats['announcements_last_7_days'] = c.fetchone()[0]
        
        conn.close()
        return stats
    
    def search_facilities(self, query: str = "", filters: Dict = None, limit: int = 100, offset: int = 0) -> List[Dict]:
        """Search facilities with filters"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        sql = "SELECT * FROM facilities WHERE 1=1"
        params = []
        
        if query:
            sql += " AND (name LIKE ? OR provider LIKE ? OR city LIKE ? OR country LIKE ?)"
            q = f"%{query}%"
            params.extend([q, q, q, q])
        
        if filters:
            if filters.get('country'):
                sql += " AND country = ?"
                params.append(filters['country'])
            if filters.get('provider'):
                sql += " AND provider = ?"
                params.append(filters['provider'])
            if filters.get('status'):
                sql += " AND status = ?"
                params.append(filters['status'])
            if filters.get('min_power'):
                sql += " AND power_mw >= ?"
                params.append(filters['min_power'])
            if filters.get('region'):
                sql += " AND region = ?"
                params.append(filters['region'])
        
        sql += f" ORDER BY confidence DESC, power_mw DESC LIMIT {limit} OFFSET {offset}"
        
        c.execute(sql, params)
        results = [dict(row) for row in c.fetchall()]
        conn.close()
        return results
    
    def export_json(self, filepath: str = "facilities_export.json"):
        """Export all facilities to JSON"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute("SELECT * FROM facilities ORDER BY country, city, name")
        facilities = [dict(row) for row in c.fetchall()]
        
        c.execute("SELECT * FROM announcements ORDER BY published_date DESC")
        announcements = [dict(row) for row in c.fetchall()]
        
        stats = self.get_stats()
        
        export = {
            "exported_at": datetime.utcnow().isoformat(),
            "stats": stats,
            "facilities": facilities,
            "announcements": announcements
        }
        
        with open(filepath, 'w') as f:
            json.dump(export, f, indent=2)
        
        conn.close()
        logger.info(f"Exported {len(facilities)} facilities to {filepath}")
        return filepath


# =============================================================================
# DATA SOURCE IMPLEMENTATIONS
# =============================================================================

class BaseSource(ABC):
    """Base class for all data sources"""
    
    name: str = "Unknown"
    source_type: str = "api"
    reliability: float = 0.5
    rate_limit: float = 1.0
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'DCHub-Nexus/3.0 (https://dchub.cloud; contact@dchub.cloud)'
        })
        self.last_request = 0
    
    def _rate_limit(self):
        """Enforce rate limiting"""
        elapsed = time.time() - self.last_request
        if elapsed < self.rate_limit:
            time.sleep(self.rate_limit - elapsed)
        self.last_request = time.time()
    
    def _safe_request(self, url: str, **kwargs) -> Optional[requests.Response]:
        """Make rate-limited request with error handling"""
        self._rate_limit()
        try:
            resp = self.session.get(url, timeout=30, **kwargs)
            resp.raise_for_status()
            return resp
        except Exception as e:
            logger.warning(f"{self.name}: Request failed - {e}")
            return None
    
    def _generate_id(self, *args) -> str:
        """Generate deterministic ID from components"""
        key = "-".join(str(a).lower().strip() for a in args if a)
        return hashlib.md5(key.encode()).hexdigest()[:16]
    
    @abstractmethod
    def fetch_facilities(self) -> List[Facility]:
        """Fetch facilities from source"""
        pass
    
    def fetch_announcements(self) -> List[Announcement]:
        """Fetch announcements (override if supported)"""
        return []


# -----------------------------------------------------------------------------
# TIER 1: FREE APIs (Run Daily)
# -----------------------------------------------------------------------------

class PeeringDBSource(BaseSource):
    """PeeringDB - Internet exchange and facility data"""
    
    name = "PeeringDB"
    source_type = "api"
    reliability = 0.95
    rate_limit = 0.5
    
    def fetch_facilities(self) -> List[Facility]:
        facilities = []
        
        # Fetch facilities
        resp = self._safe_request("https://www.peeringdb.com/api/fac")
        if not resp:
            return facilities
        
        data = resp.json().get('data', [])
        logger.info(f"PeeringDB: Processing {len(data)} facilities")
        
        for fac in data:
            try:
                # Get connectivity info
                connectivity = {
                    'networks': fac.get('net_count', 0),
                    'ix_count': fac.get('ix_count', 0),
                }
                
                facility = Facility(
                    id=self._generate_id('pdb', fac['id']),
                    name=fac.get('name', ''),
                    provider=fac.get('org_name', ''),
                    address=fac.get('address1', ''),
                    city=fac.get('city', ''),
                    state=fac.get('state', ''),
                    country=fac.get('country', ''),
                    region=self._map_region(fac.get('country', '')),
                    latitude=float(fac.get('latitude') or 0),
                    longitude=float(fac.get('longitude') or 0),
                    status='active',
                    connectivity=connectivity,
                    source=self.name,
                    source_url=f"https://www.peeringdb.com/fac/{fac['id']}",
                    source_id=str(fac['id']),
                    confidence=self.reliability,
                    raw_data=fac
                )
                facilities.append(facility)
            except Exception as e:
                logger.debug(f"PeeringDB: Error processing facility - {e}")
        
        logger.info(f"PeeringDB: Extracted {len(facilities)} facilities")
        return facilities
    
    def _map_region(self, country: str) -> str:
        na = ['US', 'CA', 'MX']
        latam = ['BR', 'AR', 'CL', 'CO', 'PE', 'VE']
        apac = ['CN', 'JP', 'KR', 'AU', 'SG', 'HK', 'IN', 'TW', 'NZ', 'MY', 'TH', 'ID', 'PH', 'VN']
        if country in na:
            return 'NA'
        elif country in latam:
            return 'LATAM'
        elif country in apac:
            return 'APAC'
        else:
            return 'EMEA'


class OpenStreetMapSource(BaseSource):
    """OpenStreetMap Overpass API - Community-mapped data centers"""
    
    name = "OpenStreetMap"
    source_type = "api"
    reliability = 0.75
    rate_limit = 10.0  # Be very respectful of OSM
    
    OVERPASS_URL = "https://overpass-api.de/api/interpreter"
    
    def fetch_facilities(self) -> List[Facility]:
        facilities = []
        
        # Overpass query for data centers
        query = """
        [out:json][timeout:120];
        (
          node["building"="data_centre"];
          way["building"="data_centre"];
          node["building"="data_center"];
          way["building"="data_center"];
          node["telecom"="data_center"];
          way["telecom"="data_center"];
          node["man_made"="data_center"];
          way["man_made"="data_center"];
        );
        out center meta;
        """
        
        try:
            resp = self.session.post(
                self.OVERPASS_URL,
                data={'data': query},
                timeout=180
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.error(f"OpenStreetMap: Query failed - {e}")
            return facilities
        
        elements = data.get('elements', [])
        logger.info(f"OpenStreetMap: Processing {len(elements)} elements")
        
        for el in elements:
            try:
                tags = el.get('tags', {})
                
                # Get coordinates
                lat = el.get('lat') or el.get('center', {}).get('lat', 0)
                lon = el.get('lon') or el.get('center', {}).get('lon', 0)
                
                # Build name
                name = tags.get('name') or tags.get('operator') or f"Data Center {el['id']}"
                
                facility = Facility(
                    id=self._generate_id('osm', el['id']),
                    name=name,
                    provider=tags.get('operator', ''),
                    address=tags.get('addr:street', ''),
                    city=tags.get('addr:city', ''),
                    state=tags.get('addr:state', ''),
                    country=tags.get('addr:country', ''),
                    latitude=float(lat),
                    longitude=float(lon),
                    status='active',
                    source=self.name,
                    source_url=f"https://www.openstreetmap.org/{el['type']}/{el['id']}",
                    source_id=str(el['id']),
                    confidence=self.reliability,
                    raw_data=el
                )
                facilities.append(facility)
            except Exception as e:
                logger.debug(f"OpenStreetMap: Error processing element - {e}")
        
        logger.info(f"OpenStreetMap: Extracted {len(facilities)} facilities")
        return facilities


class WikidataSource(BaseSource):
    """Wikidata SPARQL - Structured knowledge base"""
    
    name = "Wikidata"
    source_type = "api"
    reliability = 0.80
    rate_limit = 2.0
    
    SPARQL_URL = "https://query.wikidata.org/sparql"
    
    def fetch_facilities(self) -> List[Facility]:
        facilities = []
        
        query = """
        SELECT ?dc ?dcLabel ?coord ?country ?countryLabel ?operator ?operatorLabel WHERE {
          ?dc wdt:P31/wdt:P279* wd:Q1640703.  # instance of data center
          OPTIONAL { ?dc wdt:P625 ?coord. }
          OPTIONAL { ?dc wdt:P17 ?country. }
          OPTIONAL { ?dc wdt:P137 ?operator. }
          SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
        }
        LIMIT 5000
        """
        
        try:
            resp = self.session.get(
                self.SPARQL_URL,
                params={'query': query, 'format': 'json'},
                timeout=60
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.error(f"Wikidata: Query failed - {e}")
            return facilities
        
        results = data.get('results', {}).get('bindings', [])
        logger.info(f"Wikidata: Processing {len(results)} results")
        
        for r in results:
            try:
                qid = r['dc']['value'].split('/')[-1]
                name = r.get('dcLabel', {}).get('value', f'Data Center {qid}')
                
                # Parse coordinates
                lat, lon = 0, 0
                if 'coord' in r:
                    coord = r['coord']['value']
                    match = re.search(r'Point\(([^ ]+) ([^ ]+)\)', coord)
                    if match:
                        lon, lat = float(match.group(1)), float(match.group(2))
                
                facility = Facility(
                    id=self._generate_id('wikidata', qid),
                    name=name,
                    provider=r.get('operatorLabel', {}).get('value', ''),
                    country=r.get('countryLabel', {}).get('value', ''),
                    latitude=lat,
                    longitude=lon,
                    status='active',
                    source=self.name,
                    source_url=f"https://www.wikidata.org/wiki/{qid}",
                    source_id=qid,
                    confidence=self.reliability,
                    raw_data=r
                )
                facilities.append(facility)
            except Exception as e:
                logger.debug(f"Wikidata: Error processing result - {e}")
        
        logger.info(f"Wikidata: Extracted {len(facilities)} facilities")
        return facilities


class SECEdgarSource(BaseSource):
    """SEC EDGAR - REIT and infrastructure company filings"""
    
    name = "SEC-EDGAR"
    source_type = "api"
    reliability = 0.98
    rate_limit = 0.5
    
    # Major data center REITs and operators
    COMPANIES = {
        'Equinix': '0001101239',
        'Digital Realty': '0001297996',
        'American Tower': '0001053507',
        'Crown Castle': '0001051470',
        'CoreSite': '0001347652',
        'CyrusOne': '0001553023',
        'QTS Realty': '0001537054',
    }
    
    def fetch_facilities(self) -> List[Facility]:
        """Note: SEC doesn't directly list facilities, but we can extract from filings"""
        return []
    
    def fetch_announcements(self) -> List[Announcement]:
        announcements = []
        
        for company, cik in self.COMPANIES.items():
            try:
                # Get recent filings
                url = f"https://data.sec.gov/submissions/CIK{cik}.json"
                resp = self._safe_request(url)
                if not resp:
                    continue
                
                data = resp.json()
                filings = data.get('filings', {}).get('recent', {})
                
                forms = filings.get('form', [])
                dates = filings.get('filingDate', [])
                accessions = filings.get('accessionNumber', [])
                descriptions = filings.get('primaryDocDescription', [])
                
                for i in range(min(10, len(forms))):
                    if forms[i] in ['8-K', '10-K', '10-Q']:
                        ann = Announcement(
                            id=self._generate_id('sec', accessions[i]),
                            title=f"{company} {forms[i]} Filing",
                            summary=descriptions[i] if i < len(descriptions) else '',
                            source=self.name,
                            source_url=f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={cik}",
                            published_date=dates[i] if i < len(dates) else '',
                            announcement_type='filing',
                            companies=[company],
                            confidence=self.reliability
                        )
                        announcements.append(ann)
                
                self._rate_limit()
            except Exception as e:
                logger.warning(f"SEC-EDGAR: Error fetching {company} - {e}")
        
        logger.info(f"SEC-EDGAR: Extracted {len(announcements)} filings")
        return announcements


# -----------------------------------------------------------------------------
# TIER 2: WEB SCRAPING (Run Weekly)
# -----------------------------------------------------------------------------

class CloudsceneSource(BaseSource):
    """Cloudscene - Global data center directory"""
    
    name = "Cloudscene"
    source_type = "scrape"
    reliability = 0.85
    rate_limit = 2.0
    
    REGIONS = ['north-america', 'europe', 'asia-pacific', 'latin-america', 'middle-east', 'africa']
    
    def fetch_facilities(self) -> List[Facility]:
        if not HAS_BS4:
            logger.warning("Cloudscene: BeautifulSoup not installed")
            return []
        
        facilities = []
        
        for region in self.REGIONS:
            try:
                url = f"https://cloudscene.com/data-centers/{region}"
                resp = self._safe_request(url)
                if not resp:
                    continue
                
                soup = BeautifulSoup(resp.text, 'html.parser')
                
                # Find facility cards/listings
                for card in soup.select('.card, .facility-card, [data-facility], .listing-item'):
                    name_el = card.select_one('h3, h4, .title, .name, .facility-name')
                    if not name_el:
                        continue
                    
                    name = name_el.get_text(strip=True)
                    if len(name) < 3 or len(name) > 100:
                        continue
                    
                    # Try to extract location
                    location_el = card.select_one('.location, .city, .address')
                    city = location_el.get_text(strip=True) if location_el else ''
                    
                    facility = Facility(
                        id=self._generate_id('cloudscene', name, region),
                        name=name,
                        city=city,
                        region=region.replace('-', ' ').title(),
                        status='active',
                        source=self.name,
                        source_url=url,
                        confidence=self.reliability
                    )
                    facilities.append(facility)
                
            except Exception as e:
                logger.warning(f"Cloudscene: Error fetching {region} - {e}")
        
        logger.info(f"Cloudscene: Extracted {len(facilities)} facilities")
        return facilities


class DatacenterHawkSource(BaseSource):
    """DatacenterHawk - US market intelligence"""
    
    name = "DatacenterHawk"
    source_type = "scrape"
    reliability = 0.90
    rate_limit = 3.0
    
    MARKETS = [
        'northern-virginia', 'dallas', 'phoenix', 'chicago', 'atlanta',
        'silicon-valley', 'los-angeles', 'new-york', 'seattle', 'denver',
        'austin', 'houston', 'columbus', 'boston', 'portland', 'salt-lake-city',
        'las-vegas', 'minneapolis', 'detroit', 'miami', 'new-jersey'
    ]
    
    def fetch_facilities(self) -> List[Facility]:
        if not HAS_BS4:
            logger.warning("DatacenterHawk: BeautifulSoup not installed")
            return []
        
        facilities = []
        
        for market in self.MARKETS:
            try:
                url = f"https://www.datacenterhawk.com/market/{market}"
                resp = self._safe_request(url)
                if not resp:
                    continue
                
                soup = BeautifulSoup(resp.text, 'html.parser')
                
                for row in soup.select('tr[data-id], .facility-row, .facility'):
                    name_el = row.select_one('td:first-child, .name, .facility-name')
                    if not name_el:
                        continue
                    
                    name = name_el.get_text(strip=True)
                    if len(name) < 3 or len(name) > 100:
                        continue
                    
                    # Extract power if available
                    power_mw = 0
                    power_el = row.select_one('.power, [data-mw], .mw')
                    if power_el:
                        match = re.search(r'(\d+(?:\.\d+)?)\s*MW', power_el.get_text(), re.I)
                        if match:
                            power_mw = float(match.group(1))
                    
                    facility = Facility(
                        id=self._generate_id('dchawk', market, name),
                        name=name,
                        city=market.replace('-', ' ').title(),
                        country='USA',
                        region='NA',
                        power_mw=power_mw,
                        status='active',
                        source=self.name,
                        source_url=url,
                        confidence=self.reliability
                    )
                    facilities.append(facility)
                    
            except Exception as e:
                logger.warning(f"DatacenterHawk: Error fetching {market} - {e}")
        
        logger.info(f"DatacenterHawk: Extracted {len(facilities)} facilities")
        return facilities


class ProviderWebsitesSource(BaseSource):
    """Major provider websites - Official facility lists"""
    
    name = "ProviderWebsites"
    source_type = "scrape"
    reliability = 0.92
    rate_limit = 3.0
    
    PROVIDERS = {
        'Equinix': {
            'url': 'https://www.equinix.com/data-centers',
            'selector': 'a[href*="/data-centers/"]'
        },
        'Digital Realty': {
            'url': 'https://www.digitalrealty.com/data-centers',
            'selector': 'a[href*="/data-centers/"]'
        },
        'CyrusOne': {
            'url': 'https://cyrusone.com/data-centers/',
            'selector': 'a[href*="data-center"]'
        },
        'QTS': {
            'url': 'https://www.qtsdatacenters.com/data-centers',
            'selector': 'a[href*="data-centers"]'
        },
        'CoreSite': {
            'url': 'https://www.coresite.com/data-centers',
            'selector': 'a[href*="data-centers"]'
        },
        'Vantage': {
            'url': 'https://vantage-dc.com/locations/',
            'selector': 'a[href*="location"]'
        },
        'DataBank': {
            'url': 'https://www.databank.com/data-centers/',
            'selector': 'a[href*="data-center"]'
        },
        'Flexential': {
            'url': 'https://www.flexential.com/data-centers',
            'selector': 'a[href*="data-center"]'
        },
    }
    
    def fetch_facilities(self) -> List[Facility]:
        if not HAS_BS4:
            logger.warning("ProviderWebsites: BeautifulSoup not installed")
            return []
        
        facilities = []
        
        for provider, config in self.PROVIDERS.items():
            try:
                resp = self._safe_request(config['url'])
                if not resp:
                    continue
                
                soup = BeautifulSoup(resp.text, 'html.parser')
                
                seen = set()
                for link in soup.select(config['selector']):
                    name = link.get_text(strip=True)
                    href = link.get('href', '')
                    
                    if len(name) < 3 or len(name) > 100:
                        continue
                    if name in seen:
                        continue
                    seen.add(name)
                    
                    # Skip navigation/generic links
                    if any(skip in name.lower() for skip in ['learn more', 'view all', 'see all', 'contact']):
                        continue
                    
                    facility = Facility(
                        id=self._generate_id('provider', provider, name),
                        name=name,
                        provider=provider,
                        status='active',
                        source=self.name,
                        source_url=href if href.startswith('http') else config['url'],
                        confidence=self.reliability
                    )
                    facilities.append(facility)
                    
            except Exception as e:
                logger.warning(f"ProviderWebsites: Error fetching {provider} - {e}")
        
        logger.info(f"ProviderWebsites: Extracted {len(facilities)} facilities")
        return facilities


# -----------------------------------------------------------------------------
# TIER 3: NEWS & ANNOUNCEMENTS (Run Hourly)
# -----------------------------------------------------------------------------

class RSSNewsSource(BaseSource):
    """RSS feeds from industry publications"""
    
    name = "RSS-News"
    source_type = "rss"
    reliability = 0.88
    rate_limit = 1.0
    
    FEEDS = [
        ('Data Center Dynamics', 'https://www.datacenterdynamics.com/en/rss/'),
        ('Data Center Knowledge', 'https://www.datacenterknowledge.com/rss.xml'),
        ('Data Center Frontier', 'https://www.datacenterfrontier.com/feed/'),
        ('Bisnow', 'https://www.bisnow.com/rss/national'),
    ]
    
    # Keywords for announcement classification
    ANNOUNCEMENT_TYPES = {
        'new_build': ['breaks ground', 'new data center', 'announces plan', 'will build', 'construction begins', 'new campus', 'new facility'],
        'expansion': ['expands', 'expansion', 'adds capacity', 'new phase', 'additional mw', 'doubles capacity'],
        'acquisition': ['acquires', 'acquisition', 'purchases', 'buys', 'merger'],
        'funding': ['raises', 'funding', 'investment', 'financing', 'capital'],
        'partnership': ['partners', 'partnership', 'joint venture', 'collaboration'],
    }
    
    COMPANIES = [
        'Equinix', 'Digital Realty', 'CyrusOne', 'QTS', 'CoreSite', 'Vantage',
        'Microsoft', 'Google', 'Amazon', 'AWS', 'Meta', 'Facebook', 'Apple', 'Oracle',
        'NTT', 'Lumen', 'Flexential', 'DataBank', 'Stack', 'EdgeCore', 'CloudHQ',
        'Prime', 'Aligned', 'Switch', 'DataGryd', 'T5', 'Compass', 'EdgeConneX'
    ]
    
    LOCATIONS = [
        'Northern Virginia', 'Ashburn', 'Dallas', 'Phoenix', 'Chicago', 'Atlanta',
        'Silicon Valley', 'Santa Clara', 'Los Angeles', 'New York', 'Seattle',
        'Denver', 'Austin', 'Houston', 'Columbus', 'Las Vegas', 'Portland',
        'London', 'Frankfurt', 'Amsterdam', 'Paris', 'Dublin', 'Singapore',
        'Hong Kong', 'Tokyo', 'Sydney', 'Mumbai', 'São Paulo'
    ]
    
    def fetch_facilities(self) -> List[Facility]:
        return []  # News doesn't directly provide facilities
    
    def fetch_announcements(self) -> List[Announcement]:
        if not HAS_FEEDPARSER:
            logger.warning("RSS-News: feedparser not installed")
            return []
        
        announcements = []
        
        for source_name, feed_url in self.FEEDS:
            try:
                feed = feedparser.parse(feed_url)
                
                for entry in feed.entries[:20]:  # Latest 20 per source
                    title = entry.get('title', '')
                    summary = entry.get('summary', entry.get('description', ''))
                    link = entry.get('link', '')
                    published = entry.get('published', entry.get('updated', ''))
                    
                    # Combine for analysis
                    text = f"{title} {summary}".lower()
                    
                    # Classify announcement type
                    ann_type = None
                    for atype, keywords in self.ANNOUNCEMENT_TYPES.items():
                        if any(kw in text for kw in keywords):
                            ann_type = atype
                            break
                    
                    if not ann_type:
                        continue  # Skip non-relevant articles
                    
                    # Extract entities
                    companies = [c for c in self.COMPANIES if c.lower() in text]
                    locations = [l for l in self.LOCATIONS if l.lower() in text]
                    
                    # Extract power (MW)
                    power_mw = 0
                    power_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:MW|megawatt)', text, re.I)
                    if power_match:
                        power_mw = float(power_match.group(1))
                    
                    # Extract investment ($)
                    investment = 0
                    inv_match = re.search(r'\$(\d+(?:\.\d+)?)\s*(million|billion|M|B)', text, re.I)
                    if inv_match:
                        amount = float(inv_match.group(1))
                        unit = inv_match.group(2).lower()
                        if unit in ['billion', 'b']:
                            investment = amount * 1_000_000_000
                        else:
                            investment = amount * 1_000_000
                    
                    announcement = Announcement(
                        id=self._generate_id('rss', source_name, title),
                        title=title,
                        summary=summary[:500],
                        source=source_name,
                        source_url=link,
                        published_date=published,
                        announcement_type=ann_type,
                        companies=companies,
                        locations=locations,
                        power_mw=power_mw,
                        investment_usd=investment,
                        confidence=self.reliability
                    )
                    announcements.append(announcement)
                    
            except Exception as e:
                logger.warning(f"RSS-News: Error fetching {source_name} - {e}")
        
        logger.info(f"RSS-News: Extracted {len(announcements)} announcements")
        return announcements


# =============================================================================
# ANNOUNCEMENT TO FACILITY CONVERTER
# =============================================================================

class AnnouncementProcessor:
    """
    Convert new_build and expansion announcements into pending facility records.
    This allows the system to automatically track announced but not-yet-built facilities.
    """
    
    # Known location coordinates for quick lookups
    LOCATION_COORDS = {
        'northern virginia': (39.0438, -77.4874),
        'ashburn': (39.0438, -77.4874),
        'dallas': (32.8998, -97.0403),
        'phoenix': (33.4484, -112.0740),
        'chicago': (41.8781, -87.6298),
        'atlanta': (33.7490, -84.3880),
        'silicon valley': (37.3861, -122.0839),
        'santa clara': (37.3541, -121.9552),
        'los angeles': (34.0522, -118.2437),
        'new york': (40.7128, -74.0060),
        'seattle': (47.6062, -122.3321),
        'denver': (39.7392, -104.9903),
        'austin': (30.2672, -97.7431),
        'houston': (29.7604, -95.3698),
        'columbus': (39.9612, -82.9988),
        'las vegas': (36.1699, -115.1398),
        'portland': (45.5152, -122.6784),
        'london': (51.5074, -0.1278),
        'frankfurt': (50.1109, 8.6821),
        'amsterdam': (52.3676, 4.9041),
        'paris': (48.8566, 2.3522),
        'dublin': (53.3498, -6.2603),
        'singapore': (1.3521, 103.8198),
        'hong kong': (22.3193, 114.1694),
        'tokyo': (35.6762, 139.6503),
        'sydney': (-33.8688, 151.2093),
        'mumbai': (19.0760, 72.8777),
        'são paulo': (-23.5505, -46.6333),
        'oregon': (43.8041, -120.5542),
    }
    
    def __init__(self):
        self.processed_count = 0
    
    def process_announcement(self, announcement: Announcement) -> Optional[Facility]:
        """
        Convert a new_build or expansion announcement into a pending facility.
        Returns None if announcement can't be converted.
        """
        # Only process new builds and expansions
        if announcement.announcement_type not in ['new_build', 'expansion']:
            return None
        
        # Need at least one location
        if not announcement.locations:
            return None
        
        # Get primary company and location
        company = announcement.companies[0] if announcement.companies else 'Unknown'
        location = announcement.locations[0]
        
        # Try to get coordinates
        lat, lon = 0.0, 0.0
        location_key = location.lower()
        if location_key in self.LOCATION_COORDS:
            lat, lon = self.LOCATION_COORDS[location_key]
        
        # Determine status based on announcement type
        status = 'planned' if announcement.announcement_type == 'new_build' else 'construction'
        
        # Generate unique ID
        facility_id = hashlib.md5(
            f"ann-{company}-{location}-{announcement.id}".encode()
        ).hexdigest()[:16]
        
        facility = Facility(
            id=facility_id,
            name=f"{company} {location} (Announced)",
            provider=company,
            city=location,
            latitude=lat,
            longitude=lon,
            power_mw=announcement.power_mw,
            status=status,
            source='RSS-Announcement',
            source_url=announcement.source_url,
            source_id=announcement.id,
            confidence=0.60,  # Lower confidence - needs verification
            raw_data={
                'announcement_id': announcement.id,
                'announcement_title': announcement.title,
                'announcement_type': announcement.announcement_type,
                'expected_completion': announcement.expected_completion,
                'investment_usd': announcement.investment_usd
            }
        )
        
        self.processed_count += 1
        return facility
    
    def process_announcements(self, announcements: List[Announcement]) -> List[Facility]:
        """Process multiple announcements, returning list of facilities"""
        facilities = []
        for ann in announcements:
            facility = self.process_announcement(ann)
            if facility:
                facilities.append(facility)
        
        logger.info(f"AnnouncementProcessor: Converted {len(facilities)} announcements to facilities")
        return facilities


# =============================================================================
# MAIN DISCOVERY ENGINE
# =============================================================================

class NexusEngine:
    """Main orchestrator for discovery operations"""
    
    def __init__(self, db_path: str = "dc_nexus.db"):
        self.db = NexusDatabase(db_path)
        
        # Initialize announcement processor
        self.announcement_processor = AnnouncementProcessor()
        
        # Initialize all sources
        self.tier1_sources = [
            PeeringDBSource(),
            OpenStreetMapSource(),
            WikidataSource(),
            SECEdgarSource(),
        ]
        
        self.tier2_sources = [
            CloudsceneSource(),
            DatacenterHawkSource(),
            ProviderWebsitesSource(),
        ]
        
        self.tier3_sources = [
            RSSNewsSource(),
        ]
        
        self.all_sources = self.tier1_sources + self.tier2_sources + self.tier3_sources
    
    def run_quick(self) -> Dict:
        """Quick discovery - PeeringDB only"""
        logger.info("=" * 60)
        logger.info("DC HUB NEXUS - QUICK DISCOVERY")
        logger.info("=" * 60)
        
        start = time.time()
        source = PeeringDBSource()
        
        facilities = source.fetch_facilities()
        new_count = 0
        for f in facilities:
            _, is_new = self.db.upsert_facility(f)
            if is_new:
                new_count += 1
        
        duration = time.time() - start
        stats = self.db.get_stats()
        
        logger.info(f"✅ Quick discovery complete in {duration:.1f}s")
        logger.info(f"📊 New facilities: {new_count} | Total: {stats['total_facilities']}")
        
        return {
            'duration': duration,
            'facilities_new': new_count,
            'total_facilities': stats['total_facilities']
        }
    
    def run_full(self) -> Dict:
        """Full discovery - All sources"""
        logger.info("=" * 60)
        logger.info("DC HUB NEXUS - FULL DISCOVERY")
        logger.info("=" * 60)
        
        start = time.time()
        total_new = 0
        total_updated = 0
        total_announcements = 0
        
        # Run facility sources in parallel
        all_facilities = []
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = {executor.submit(s.fetch_facilities): s.name for s in self.all_sources}
            for future in as_completed(futures):
                source_name = futures[future]
                try:
                    facilities = future.result()
                    all_facilities.extend(facilities)
                    logger.info(f"  ✓ {source_name}: {len(facilities)} facilities")
                except Exception as e:
                    logger.error(f"  ✗ {source_name}: {e}")
        
        # Process facilities
        for f in all_facilities:
            _, is_new = self.db.upsert_facility(f)
            if is_new:
                total_new += 1
            else:
                total_updated += 1
        
        # Fetch announcements and convert to facilities
        all_announcements = []
        for source in self.all_sources:
            try:
                announcements = source.fetch_announcements()
                for a in announcements:
                    _, is_new = self.db.upsert_announcement(a)
                    if is_new:
                        total_announcements += 1
                        all_announcements.append(a)
            except Exception as e:
                logger.debug(f"Announcements from {source.name}: {e}")
        
        # Convert new_build/expansion announcements to pending facilities
        converted_facilities = self.announcement_processor.process_announcements(all_announcements)
        total_converted = 0
        for f in converted_facilities:
            _, is_new = self.db.upsert_facility(f)
            if is_new:
                total_converted += 1
        
        duration = time.time() - start
        stats = self.db.get_stats()
        
        logger.info("=" * 60)
        logger.info(f"✅ Full discovery complete in {duration:.1f}s")
        logger.info(f"🏢 Facilities: {stats['total_facilities']} (new: {total_new}, updated: {total_updated})")
        logger.info(f"📰 Announcements: {stats['total_announcements']} (new: {total_announcements})")
        logger.info(f"🔄 Announcements→Facilities: {total_converted}")
        logger.info(f"⚡ Total Power: {stats['total_power_mw']:,.0f} MW")
        logger.info(f"🌍 Countries: {len(stats['by_country'])}")
        logger.info(f"🏭 Providers: {len(stats['by_provider'])}")
        logger.info("=" * 60)
        
        return {
            'duration': duration,
            'facilities_new': total_new,
            'facilities_updated': total_updated,
            'announcements_new': total_announcements,
            'total_facilities': stats['total_facilities'],
            'total_announcements': stats['total_announcements'],
            'total_power_mw': stats['total_power_mw']
        }
    
    def run_news_only(self) -> Dict:
        """News/announcements only - Run hourly"""
        logger.info("📰 Running news discovery...")
        
        start = time.time()
        total_new = 0
        
        for source in self.tier3_sources:
            try:
                announcements = source.fetch_announcements()
                for a in announcements:
                    _, is_new = self.db.upsert_announcement(a)
                    if is_new:
                        total_new += 1
            except Exception as e:
                logger.error(f"News source {source.name}: {e}")
        
        duration = time.time() - start
        logger.info(f"✅ News discovery complete: {total_new} new announcements in {duration:.1f}s")
        
        return {'announcements_new': total_new, 'duration': duration}
    
    def export(self, filepath: str = "dc_nexus_export.json"):
        """Export all data to JSON"""
        return self.db.export_json(filepath)
    
    def get_stats(self) -> Dict:
        """Get current statistics"""
        return self.db.get_stats()


# =============================================================================
# CLI INTERFACE
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="DC Hub Nexus - Data Center Discovery Engine")
    parser.add_argument('--quick', action='store_true', help='Quick discovery (PeeringDB only)')
    parser.add_argument('--full', action='store_true', help='Full discovery (all sources)')
    parser.add_argument('--news', action='store_true', help='News/announcements only')
    parser.add_argument('--stats', action='store_true', help='Show statistics')
    parser.add_argument('--export', type=str, metavar='FILE', help='Export to JSON file')
    parser.add_argument('--continuous', type=int, metavar='HOURS', help='Run continuously every N hours')
    parser.add_argument('--db', type=str, default='dc_nexus.db', help='Database path')
    
    args = parser.parse_args()
    
    engine = NexusEngine(args.db)
    
    if args.stats:
        stats = engine.get_stats()
        print(json.dumps(stats, indent=2))
    elif args.quick:
        engine.run_quick()
    elif args.news:
        engine.run_news_only()
    elif args.export:
        engine.export(args.export)
    elif args.continuous:
        logger.info(f"🔄 Starting continuous mode (every {args.continuous} hours)")
        while True:
            engine.run_full()
            engine.export()
            logger.info(f"💤 Sleeping for {args.continuous} hours...")
            time.sleep(args.continuous * 3600)
    else:
        # Default: full discovery
        engine.run_full()
        engine.export()
